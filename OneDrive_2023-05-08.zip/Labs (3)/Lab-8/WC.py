from pyspark import SparkContext
if __name__ == 'main':
	sc = SparkContent("local","word count")
	sc.setLogLeve("ERROR")
	
	lines = sc.textFile("/200968080/Apache_Spark/word_count.txt")
	words = lines.flatMap(lambda line: line.split(" "))
	wc = words.countByValue()
	for word,count in wc.items():
		print("{}:{}".format(word,count))
	sc.stop()
	
