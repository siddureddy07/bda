#!/usr/bin/python3

import sys
total_count=0
for line in sys.stdin:
	line = line.strip()
	#split the line into words
	words = line.split()
	#increase counters
	total_count = total_count+1
	for word in words:
		#write the results to STDOUT, tab delimited
		#tab delimited, trivial word count is 1
		print('%s\t%s' % (word, 1))

