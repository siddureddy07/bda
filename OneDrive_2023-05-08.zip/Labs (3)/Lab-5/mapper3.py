#!/usr/bin/python3
"""mapper3.py"""
import sys

#input comes from STDIN (standard input)
for line in sys.stdin:
	#remove leading and trailing w	linehitespace
	line = line.strip()
	#split the line into words
	words = line.split()
	#increase counters
	for word in words:
		#write the results to STDOUT, tab delimited
		#tab delimited, trivial word count is 1
		print('%s\t%s' % (word, 1))
