#!/usr/bin/python3

import sys
total_count=0
days_lst=[]
days_lst=sys.stdin
print(days_lst)
