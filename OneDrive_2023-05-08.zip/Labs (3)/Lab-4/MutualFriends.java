Import java.io.IOException;
Import org.apache.hadoop.conf.Configuration;
Import org.apache.hadoop.fs.Path;
Import org.apache.hadoop.io.Text;
Import org.apache.hadoop.mapreduce.Job;
Import org.apache.hadoop.mapreduce.Mapper;
Import org.apache.hadoop.mapreduce.Reducer;
Import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
Import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

Public class MutualFriends {

  Public static class MutualFriendsMapper extends Mapper<Object, Text, Text, Text> {

    Public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
      String[] line = value.toString().split(“\t”);
      String user = line[0];
      String[] friends = line[1].split(“,”);
      For (String friend : friends) {
        Context.write(new Text(user + “,” + friend), new Text(line[1]));
      }
    }
  }

  Public static class MutualFriendsReducer extends Reducer<Text, Text, Text, Text> {

    Public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
      StringBuilder mutualFriends = new StringBuilder();
      For (Text value : values) {
        String[] friends = value.toString().split(“,”);
        If (mutualFriends.length() > 0) {
          mutualFriends.append(“,”);
        }
        mutualFriends.append(value.toString());
      }
      Context.write(key, new Text(mutualFriends.toString()));
    }
  }

  Public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
    Job job = Job.getInstance(conf, “Mutual Friends”);

    Job.setJarByClass(MutualFriends.class);
    Job.setMapperClass(MutualFriendsMapper.class);
    Job.setReducerClass(MutualFriendsReducer.class);

    Job.setOutputKeyClass(Text.class);
    Job.setOutputValueClass(Text.class);

    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(args[1]));

    System.exit(job.waitForCompletion(true) ? 0 : 1);
  }
}
