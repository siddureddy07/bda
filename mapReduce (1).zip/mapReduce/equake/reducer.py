#!/usr/bin/env python3

import sys

max_region = None
max_magnitude = 0

for line in sys.stdin:
    line = line.strip()
    region, magnitude = line.split('\t')
    magnitude = float(magnitude)
    if magnitude > max_magnitude:
        max_magnitude = magnitude
        max_region = region

if max_region:
    print('Maximum earthquake occurrence region: {}'.format(max_region))

print('List of different region names:')
for line in sys.stdin:
    line = line.strip()
    region, _ = line.split('\t')
    print(region)

