#!/usr/bin/env python3

import sys

for line in sys.stdin:
    line = line.strip()
    region, date, magnitude = line.split(',')
    print('{}\t{}'.format(region, magnitude))

