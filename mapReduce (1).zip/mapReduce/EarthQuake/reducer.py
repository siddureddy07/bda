#!/usr/bin/python

import sys

prev_word = None
prev_count = 0

max_num=0
max_country= "a"

for line in sys.stdin:
	line = line.strip()
	word, count = line.split('\t')
	
	count = int(count)
	
	if prev_word == word:
		prev_count += count
	else:
		if prev_word:
			print('%s\t%s'%(prev_word, prev_count))
		prev_count = count
		prev_word = word
	if prev_count >= max_num:
			max_num=prev_count
			max_country=prev_word
		
	
if prev_word == word:
	print('%s\t%s'%(prev_word, prev_count))

	
print("\nWhich is the country with highest number of earthquakes? : ", max_country)
print("\nWhat is this county's number of earhtquakes? : ", max_num)

