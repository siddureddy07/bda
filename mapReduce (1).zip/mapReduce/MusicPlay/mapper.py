#!/usr/bin/env python3

import sys

for line in sys.stdin:
    line = line.strip()
    track_id, listener_id, download_time, share_time = line.split(',')

    # Emit key-value pairs for maximum download time and count of unique listeners
    print('download_time\t{}\t{}'.format(track_id, download_time))
    print('unique_listeners\t{}\t{}'.format(track_id, listener_id))
    print('shared_time\t{}\t{}'.format(track_id, share_time))

