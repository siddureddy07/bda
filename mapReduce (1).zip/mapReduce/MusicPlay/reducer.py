#!/usr/bin/env python3

import sys

max_download_time = 0
max_download_track_id = None

unique_listeners_count = 0
unique_listeners_track_id = None

max_share_time = 0
max_share_track_id = None

for line in sys.stdin:
    line = line.strip()
    key, track_id, time = line.split('\t')

    if key == 'download_time':
        time = time.strip()
        if time > max_download_time:
            max_download_time = time
            max_download_track_id = track_id

    elif key == 'unique_listeners':
        if unique_listeners_track_id != track_id:
            unique_listeners_count += 1
            unique_listeners_track_id = track_id

    elif key == 'shared_time':
        time = time.strip()
        if time > max_share_time:
            max_share_time = time
            max_share_track_id = track_id

# Output the results
print('Maximum Time the track was downloaded: Track ID - {}, Time - {}'.format(max_download_track_id, max_download_time))
print('Count of Unique Listeners: {}'.format(unique_listeners_count))
print('Number of Listeners usage of same track: Not implemented')
print('Maximum Time the track was shared with others: Track ID - {}, Time - {}'.format(max_share_track_id, max_share_time))

