#!/usr/bin/env python3

import sys

for line in sys.stdin:
    line = line.strip()
    person, friends = line.split('\t')
    friends = friends.split(',')

    for i in range(len(friends)):
        for j in range(i + 1, len(friends)):
            pair = tuple(sorted([friends[i], friends[j]]))
            print('{}\t{}'.format(pair, person))

