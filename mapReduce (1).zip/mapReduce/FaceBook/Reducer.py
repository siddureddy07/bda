#!/usr/bin/env python3

import sys

current_pair = None
current_friends = []

for line in sys.stdin:
    line = line.strip()
    pair, friend = line.split('\t')
    
    # check if the pair has changed
    if current_pair != pair:
        # output the previous pair with their mutual friends
        if current_pair and len(current_friends) > 1:
            print('{}\t{}'.format(current_pair, ','.join(current_friends)))
        
        # reset the current pair and friends list
        current_pair = pair
        current_friends = []

    # add the friend to the current friends list
    current_friends.append(friend)

# output the last pair with their mutual friends
if current_pair and len(current_friends) > 1:
    print('{}\t{}'.format(current_pair, ','.join(current_friends)))

